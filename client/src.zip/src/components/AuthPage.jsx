import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { GoogleLogin, GoogleOAuthProvider } from '@react-oauth/google';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setUser } from '../redux/userSlice';
import '../styles/AuthPage.css';
import { FaEye, FaEyeSlash } from 'react-icons/fa';

const AuthPage = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [message, setMessage] = useState({ text: '', type: '' });
    const [isLoading, setIsLoading] = useState(false);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [searchParams] = useSearchParams();
    const clientId = process.env.REACT_APP_GOOGLE_CLIENT_ID || '';

    useEffect(() => {
        const verificationStatus = searchParams.get('verification_status');
        if (verificationStatus) {
            if (verificationStatus === 'success') {
                setMessage({ text: 'האימייל אומת בהצלחה! כעת ניתן להתחבר.', type: 'success' });
            } else { // 'failure'
                setMessage({ text: 'אימות האימייל נכשל. ייתכן שהקישור אינו תקין או שפג תוקפו. אנא נסה שנית.', type: 'error' });
            }
            navigate('/auth', { replace: true });
        }
    }, [searchParams, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage({ text: '', type: '' });

        if (password.length < 8) {
            setMessage({ text: 'הסיסמה חייבת להכיל לפחות 8 תווים.', type: 'error' });
            return;
        }
        
        setIsLoading(true);

        try {
            const res = await axios.post(`${process.env.REACT_APP_API_DOMAIN}/api/v1/auth`, { email, password });

            if (res.data.action === 'login') {
                document.cookie = `token=${res.data.token}; path=/`;
                localStorage.setItem('user', JSON.stringify(res.data.user));
                dispatch(setUser(res.data.user));
                navigate('/');
            } else if (res.data.status === 'verification-resent' || res.data.status === 'user-created') {
                setMessage({ text: res.data.message, type: 'success' });
            }
        } catch (error) {
            const errorMessage = error.response?.data?.error || 'אירעה שגיאה. אנא נסה שוב.';
            setMessage({ text: errorMessage, type: 'error' });
        } finally {
            setIsLoading(false);
        }
    };
    
    const responseGoogle = async (credentialResponse) => {
        if (credentialResponse.credential) {
            setIsLoading(true);
            try {
                const res = await axios.post(`${process.env.REACT_APP_API_DOMAIN}/api/v1/google`, { tokenId: credentialResponse.credential });
                dispatch(setUser(res.data.user));
                document.cookie = `token=${res.data.token}; path=/`;
                localStorage.setItem('user', JSON.stringify(res.data.user));
                navigate('/');
            } catch (error) {
                setMessage({
                    text: error.response?.data?.error || 'התחברות גוגל נכשלה.',
                    type: 'error'
                });
            } finally {
                setIsLoading(false);
            }
        }
    };
    
    const handleClose = () => {
        navigate('/');
    };

    return (
        <GoogleOAuthProvider clientId={clientId}>
            <div className="modal-overlay">
                {isLoading && (
                    <div className="spinner-overlay">
                        <div className="spinner"></div>
                    </div>
                )}
                <div className="modal-content" /*style={{ opacity: isLoading ? 0.7 : 1 }}*/>
                    <button onClick={handleClose} className="btn btn-ghost btn-circle btn-sm btn-close">×</button>
                    <h2>בואו ניכנס</h2>
                    <p> הצטרפו עכשיו והתחילו לגלות דברים מעניינים סביבכם</p>
                    
                    <div className="auth-content">
                        <GoogleLogin
                            onSuccess={responseGoogle}
                            onError={() => {
                                setMessage({
                                    text: 'התחברות גוגל נכשלה.',
                                    type: 'error'
                                });
                            }}
                            useOneTap
                            shape="pill"
                            width="350px"
                        />
                        <div className="divider">התחברות פשוטה עם כתובת המייל שלכם</div>
                        <form onSubmit={handleSubmit} className="email-form">
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="כתובת מייל"
                                required
                                autoFocus
                            />
                            <div className="input-with-icon-container">
                                <input
                                    type={showPassword ? "text" : "password"}
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="סיסמה"
                                    required
                                />
                                <span onClick={() => setShowPassword(!showPassword)} className="input-icon">
                                    {showPassword ? <FaEyeSlash /> : <FaEye />}
                                </span>
                            </div>
                            <div className="actions-container">
                                <button type="submit" className="btn btn-solid btn-primary" disabled={isLoading}>המשך</button>
                            </div>
                            <a href="/forgot-password" onClick={(e) => { e.preventDefault(); navigate('/forgot-password');}} className="forgot-password-link">
                                יצירת סיסמה חדשה
                            </a>
                            {message.text && (
                                <p className={`auth-message ${message.type === 'success' ? 'success-message' : 'error-message'}`}>
                                    {message.text}
                                </p>
                            )}
                        </form>
                    </div>
                </div>
            </div>
        </GoogleOAuthProvider>
    );
};

export default AuthPage;